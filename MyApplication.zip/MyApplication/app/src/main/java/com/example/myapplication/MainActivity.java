package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Context context = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        ImageButton playButton = (ImageButton)findViewById(R.id.playButton);
        ImageButton btnNavTopPlayers = (ImageButton)findViewById(R.id.btnNavTopPlayers);
        ImageButton btnNavSettings = (ImageButton)findViewById(R.id.btnNavSettings);

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GameView gameView = new GameView(context);
                setContentView(gameView);
            }
        });

        btnNavTopPlayers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MenuTopPlayers.class);
                startActivity(intent);
            }
        });
        btnNavSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, menu_settings.class);
                startActivity(intent);
            }
        });
    }
}