package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.Random;

public class Ghost {
    Bitmap ghost[] = new Bitmap[3];
    int ghostFrame = 0;
    int ghostX, ghostY, ghostVelocity;
    Random random;
    private Context context;

    public Ghost(Context current, int index){
        this.context = current;
        int draw =  R.drawable.red;
        if(index == 1)
            draw = R.drawable.green;
        else if (index == 2)
            draw = R.drawable.pink;
        ghost[0] = BitmapFactory.decodeResource(context.getResources(),draw);
        ghost[1] = BitmapFactory.decodeResource(context.getResources(), draw);
        ghost[2] = BitmapFactory.decodeResource(context.getResources(), draw);
        random = new Random();
        resetPosition();
    }



    public Bitmap getGhost(int ghostFrame){
        return ghost[ghostFrame];
    }

    public int getGhostWidth(){
        return ghost[0].getWidth();
    }

    public int getGhostHeight(){
        return ghost[0].getHeight();
    }

    public void resetPosition(){
        ghostX = random.nextInt(GameView.dWidth - getGhostWidth());
        ghostY = -200 + random.nextInt(600)* -1;
        ghostVelocity = 35 + random.nextInt(16);
    }
}
