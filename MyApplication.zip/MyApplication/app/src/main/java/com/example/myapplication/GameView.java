package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;
import java.util.Random;


public class GameView extends View {

    Bitmap background, wall, hero;
    Rect rectBackground, rectWall;
    Context context;
    Handler handler;
    final long UPDATE_MILLIS = 20;
    Runnable runnable;
    Paint textPaint = new Paint();
    Paint healthPaint = new Paint();
    float TEXT_SIZE = 120;
    int points = 0;
    int life = 3;
    static int dWidth, dHeight;
    Random random;
    float heroX, heroY;
    float oldX;
    float oldHeroX;
    ArrayList<Ghost> ghosts;
    ArrayList<Explosion> explosions;

    public GameView(Context context)  {
        super(context);
        this.context = context;
        background = BitmapFactory.decodeResource(getResources(), R.drawable.background_1);
        wall = BitmapFactory.decodeResource(getResources(), R.drawable.wall);
        hero = BitmapFactory.decodeResource(getResources(), R.drawable.hero);
        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;
        rectBackground = new Rect(0,0, dWidth, dHeight);
        rectWall = new Rect(0,dHeight - wall.getHeight(),dWidth,dHeight);
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        };

        textPaint.setColor(Color.rgb(255,165,0));
        textPaint.setTextSize(TEXT_SIZE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(ResourcesCompat.getFont(context, R.font.montserrat_subrayada_bold));
        healthPaint.setColor(Color.GREEN);
        random = new Random();
        heroX = dWidth / 2 - hero.getWidth() / 2;
        heroY = dHeight - wall.getHeight() - hero.getHeight();

        ghosts = new ArrayList<>();

        for(int i = 0; i < 3; i++){
            Ghost ghost = new Ghost(context, i);
            ghosts.add(ghost);
        }
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawBitmap(background, null, rectBackground,null);
        canvas.drawBitmap(wall,null,rectWall,null);
        canvas.drawBitmap(hero,heroX,heroY,null);
        for (int i = 0; i < ghosts.size(); i++){
            canvas.drawBitmap(ghosts.get(i).getGhost(ghosts.get(i).ghostFrame), ghosts.get(i).ghostX, ghosts.get(i).ghostY, null);
            ghosts.get(i).ghostFrame++;
            if(ghosts.get(i).ghostFrame > 2){
                ghosts.get(i).ghostFrame = 0;
            }
            ghosts.get(i).ghostY += ghosts.get(i).ghostVelocity;

            if(ghosts.get(i).ghostY + ghosts.get(i).getGhostHeight() >= dHeight - wall.getHeight()){
                points += 10;
                /*
                Explosion explosion = new Explosion(context);
                explosion.explosionX = ghosts.get(i).ghostX;
                explosion.explosionY = ghosts.get(i).ghostY;
                explosions.add(explosion);
                 */
                ghosts.get(i).resetPosition();
            }
        }

        for(int i =0; i<ghosts.size();i++){
            if(ghosts.get(i).ghostX + ghosts.get(i).getGhostWidth() >= heroX
            && ghosts.get(i).ghostX <= hero.getWidth() + heroX
            && ghosts.get(i).ghostY + ghosts.get(i).getGhostWidth() >= heroY
            && ghosts.get(i).ghostY + ghosts.get(i).getGhostWidth() <= heroY + hero.getHeight()){
                life--;
                ghosts.get(i).resetPosition();
                if(life == 0){
                    Intent intent = new Intent(context, GameOver.class);
                    intent.putExtra("points", points);
                    context.startActivity(intent);
                    ((Activity) context).finish();
                }
            }
        }
        if(life == 2){
            healthPaint.setColor(Color.YELLOW);
        }
        else if(life == 1){
            healthPaint.setColor(Color.RED);
        }
        // Отрисовка здоровья
        canvas.drawRect(dWidth-200,30,dWidth-200+60*life, 80,healthPaint);
        canvas.drawText(""+points, 20, TEXT_SIZE, textPaint);
        handler.postDelayed(runnable, UPDATE_MILLIS);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        if(touchY >= heroY){
            int action = event.getAction();
            if(action == MotionEvent.ACTION_DOWN){
                oldX = event.getX();
                oldHeroX = heroX;
            }
            if(action == MotionEvent.ACTION_MOVE){
                float shift = oldX - touchX;
                float newHeroX = oldHeroX - shift;
                if(newHeroX <= 0)
                    heroX = 0;
                else if(newHeroX >= dWidth - hero.getWidth())
                    heroX = dWidth - hero.getWidth();
                else
                    heroX = newHeroX;
            }
        }
        return true;
    }
}
